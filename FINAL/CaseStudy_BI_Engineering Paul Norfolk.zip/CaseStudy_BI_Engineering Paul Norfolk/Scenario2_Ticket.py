##################################################################################################################################
# This Script has been written to Transform the file 'ticket_example.csv' into a more usable format for visualisation in Tableau 
#                                                                                                                                
# The columns 'custom fields', 'satisfaction rating' and 'via' contain data that should be broken into multiple fields           
# This script will break these into multiple relevant fields                                                                   
#
# The column 'tags' contains multiple tags associated with the ticket
# As it is a many-to-one relationship this script will create unique keys for the ticket and for the tags, and then 
# use a join table containing both keys to show the relationship between tickets and tags
###################################################################################################################################

# 1. Importing Modules and reading the Data 
# importing modules needed  
import pandas as pd
import numpy as np

# Read the 'ticket_example.csv' file into a dataframe so we can work with it
df_initial = pd.read_csv("ticket_example.csv", encoding='cp1252', sep=';')


# 2. Breaking up columns into multiple columns where needed
# 2.1. Start with 'Custom_fields'  
# Next we want to break the column 'custom_fields' into multiple seperate fields
# Split column 'custom_fields' into it's components based on ','
custom_fields=df_initial['custom_fields'].str.split(',', expand=True)

# Even columns are just the column names (e.g Call Duration) so we can drop them as we only want the values
custom_fields = custom_fields.drop([0,2,4,6],axis=1)
# Rename the value columns
custom_fields.columns = ['custom_fields_Call Duration', 'custom_fields_Firma', 'custom_fields_Call End', 'custom_fields_Call Start']

# Now we want to clean the value columns
# We want to read after the ':' and remove curly/square brackets to leave just text
# To make it easier, loop over the columns to do them all at once
for column in custom_fields:
    custom_fields[column] = custom_fields[column].str.split(':').str[1]
    custom_fields[column] = custom_fields[column].str.replace('}','')
    custom_fields[column] = custom_fields[column].str.replace(']','')

# We now have a dataframe called custom_fields which contains the custom_fields data in multiple columns
# We'll join this back onto the main data once we've done the other columns
    

# 2.2. Do the same thing for satisfaction_rating:
# Next we want to break the column 'satisfaction_rating' into multiple seperate fields
# Split column 'satisfaction_rating' into it's components based on ','
satisfaction_rating=df_initial['satisfaction_rating'].str.split(',', expand=True)

# Rename the value columns
satisfaction_rating.columns = ['satisfaction_rating_assignee_id','satisfaction_rating_created_at','satisfaction_rating_group_id','satisfaction_rating_id','satisfaction_rating_requester_id',
                              'satisfaction_rating_score','satisfaction_rating_ticket_id','satisfaction_rating_updated_at','satisfaction_rating_url',]

# Now we want to clean the value columns
# We want to read after the ':' and remove curly/square brackets to leave just text
# To make it easier, loop over the columns to do them all at once
for column in satisfaction_rating:
    satisfaction_rating[column] = satisfaction_rating[column].str.split(':').str[1]
    satisfaction_rating[column] = satisfaction_rating[column].str.replace('}','')
    satisfaction_rating[column] = satisfaction_rating[column].str.replace(']','')
    satisfaction_rating[column] = satisfaction_rating[column].str.replace("'",'')

# We now have a dataframe called satisfaction_rating which contains the satisfaction_rating data in multiple columns
# We'll join this back onto the main data once we've done the other columns
    
# 2.3. Do the same thing for via:
# Next we want to break the column 'via' into multiple seperate fields
# Split column 'via' into it's components based on ','
via=df_initial['via'].str.split(',', expand=True)

# Rename the value columns
via.columns = ['via_channel','via_source_from_address','via_source_from_name','via_source_from_rel','via_source_to_name',
                             'via_source_to_address']

# Now we want to clean the value columns
# We want to read after the ':' and remove curly/square brackets to leave just text
# To make it easier, loop over the columns to do them all at once

# Some of the columns have values at different places in the borken string columns, so we'll repeat the cleaning section below for different positions after the ':' seperator

Col1 = ['via_channel','via_source_from_name','via_source_from_rel','via_source_to_address']
for column in Col1:
    via[column] = via[column].str.split(':').str[1]
    via[column] = via[column].str.replace('}','')
    via[column] = via[column].str.replace(']','')
    via[column] = via[column].str.replace("'",'')
    via[column] = via[column].str.strip()
    via.loc[via[column] == "{", column] = 'None' 
    
Col2 =['via_source_to_name']
for column in Col2:
    via[column] = via[column].str.split(':').str[2]
    via[column] = via[column].str.replace('}','')
    via[column] = via[column].str.replace(']','')
    via[column] = via[column].str.replace("'",'')
    

Col3 =['via_source_from_address']
for column in Col3:
    via[column] = via[column].str.split(':').str[3]
    via[column] = via[column].str.replace('}','')
    via[column] = via[column].str.replace(']','')
    via[column] = via[column].str.replace("'",'')
    via[column] = via[column].fillna('None')

# We now have a dataframe called via which contains the via data in multiple columns
# We'll join this back onto the main data once we've done the other columns


# 3. We need to create a dimensional table with all possible values for Tags alogn with a unique for them
# Start by splittin tags in to seperate columns to seperate the various tags on each ticket
tags=df_initial['tags'].str.split(',', expand=True)
# Clean up the data for tags, removing curly/square brackets to leave just text
for column in tags:
    tags[column] = tags[column].str.replace('[','')
    tags[column] = tags[column].str.replace(']','')
    tags[column] = tags[column].str.replace("'",'')
    tags[column] = tags[column].str.strip()
    
# Let's start making the master list of tags:
# append all tags to create one big list
tag_master_list=tags[0]
for column in [1,2,3,4,5]:
    tag_list=tags[column]
    tag_master_list=tag_master_list.append(tag_list, ignore_index=True)
# Delete any duplicates - we only want each unique tag once in this dimensional table
tag_master_list = tag_master_list.drop_duplicates()
# put it back in a dataframe to continue working with
tag_master_list = pd.DataFrame (tag_master_list)
# Remove 'None' as is not a tag - it is a null
tag_master_list=tag_master_list.dropna()
# Create unique key for each tag
tag_master_list['Tag_key'] = np.arange(len(tag_master_list))
# Rename columns
tag_master_list.columns = ['Tag', 'Tag_Key']
# Order columns
tag_master_list = tag_master_list.reindex(columns = ['Tag_Key','Tag'])

# We now have a dimensional table for Tags with a master list of all possible tags along with a unique key for them


# 4. Creating a Join Table
# As Tickets-Tags relationship is many-to-one we need to create a join table that includes keys for both tickets and tags with their relationships
# start by joining all tags on to the ticket table - we created this table in preparation for the tags dimensional table, so we'll re-use the tags dataframe 
Join_Table_initial=pd.merge(df_initial['id'], tags, left_index=True, right_index=True)
# Melt table from wide to long format to create table of keys
# This now creates a long table listing out tickets with all their relevant tags (one row per relationship)
Join_Table_melt=pd.melt(Join_Table_initial, id_vars=['id'], value_vars=[0,1,2,3,4,5], value_name='Tag')
# Drop any nulls
Join_Table_clean=Join_Table_melt.dropna()
# Join on Tag_key from tag_master_list - in the join table we need the keys not the actual tag, so join on the key
Join_Table_tag_key=Join_Table_clean.merge(tag_master_list, how='left', on='Tag')
# Remove the column for the tag, keeping just the Ticket Key and Tag Key
Join_Table=Join_Table_tag_key.drop(['variable','Tag'],axis=1)

# We now have a Join Table for Tickets and Tags. This contains 2 columns, Ticket id and Tag_key
# so each row defines a relationship between a ticket and a tag


# 5.Bringing this alltogether 
# Join on all columns we created earlier (for custom_fields, satisfaction_rating and via)
Tickets1=pd.merge(df_initial, custom_fields, left_index=True, right_index=True)
Tickets2=pd.merge(Tickets1, satisfaction_rating, left_index=True, right_index=True)
Tickets3=pd.merge(Tickets2, via, left_index=True, right_index=True)

# Drop unneeded fields - original fields aren't needed as their data is now in seperate columns
Tickets_Final=Tickets3.drop(['custom_fields','satisfaction_rating','via','tags'],axis=1)


# Save files to csv
Tickets_Final.to_csv('Tickets.csv',index=False)      # saving final table with Ticket information
Join_Table.to_csv('Join_Table.csv',index=False)      # saving Join table with keys for the Tickets and Tags
tag_master_list.to_csv('dim_Tags.csv',index=False)   # saving tag dimensional table